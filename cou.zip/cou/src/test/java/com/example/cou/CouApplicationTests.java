package com.example.cou;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

@SpringBootTest
class CouApplicationTests {

    @Test
    void contextLoads() {

    }

}
